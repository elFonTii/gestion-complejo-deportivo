module.exports = {

    database: {
        host : 'localhost',
        user : 'root',
        password : '',
        database : 'gestioncomplejo',
        //Nos permite que la fecha sea facil de leer para el usuario.
        dateStrings: 'date'
    }
}